<template>
  <ul class="listview image-listview flush transparent pt-1">
    <li>
      <div class="item">
        <div class="icon-box bg-primary">
          <ion-icon
            name="image-outline"
            role="img"
            class="md hydrated"
            aria-label="image outline"
          ></ion-icon>
        </div>
        <div class="in">
          <div>Dự án đang đảm nhận</div>
          <span class="badge badge-danger">0</span>
        </div>
      </div>
    </li>
    <li>
      <div class="item">
        <div class="icon-box bg-secondary">
          <ion-icon
            name="videocam-outline"
            role="img"
            class="md hydrated"
            aria-label="videocam outline"
          ></ion-icon>
        </div>
        <div class="in">
          <div>Videos</div>
          <span class="text-muted">None</span>
        </div>
      </div>
    </li>
    <li>
      <div class="item">
        <div class="icon-box bg-danger">
          <ion-icon
            name="musical-notes-outline"
            role="img"
            class="md hydrated"
            aria-label="musical notes outline"
          ></ion-icon>
        </div>
        <div class="in">
          <div>Music</div>
        </div>
      </div>
    </li>
  </ul>
</template>

<script>
export default {};
</script>

<style>
</style>