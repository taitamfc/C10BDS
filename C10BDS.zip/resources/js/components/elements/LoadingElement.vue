<template>
    <div id="loader" style="opacity: 0.7;">
        <div class="spinner-border text-warning" role="status"></div>
    </div>
</template>

<script>
export default {    

}
</script>

<style>

</style>